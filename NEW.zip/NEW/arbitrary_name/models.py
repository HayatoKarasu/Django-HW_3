from django.db import models


class Human(models.Model):
    Фамилия = models.CharField(max_length=30)
    Имя = models.CharField(max_length=30)
    Отчество = models.CharField(max_length=30)
    Место_жительства = models.CharField(max_length=100)
    Дата_рождения = models.DateField()
    Характеристика = models.TextField(blank=True)
    Фотография = models.ImageField(upload_to='photo/%Y/%m/%d')
    Дата_и_время_последних_изменений = models.DateTimeField(auto_now=True)
    Регистрация = models.BooleanField(default=True)