from django.contrib import admin
from django.urls import path

from arbitrary_name.views import index2, just

urlpatterns = [
    path('', index2),
    path('just', just),
]